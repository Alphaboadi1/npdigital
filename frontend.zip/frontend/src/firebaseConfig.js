import { initializeApp } from "firebase/app";

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDsyhWKcedRqICNBOaENz3U2NBn40afqN8",
  authDomain: "digitaltool-a5760.firebaseapp.com",
  projectId: "digitaltool-a5760",
  storageBucket: "digitaltool-a5760.appspot.com",
  messagingSenderId: "690449191827",
  appId: "1:690449191827:web:b4cff17b40dd83a9a9ce66"
};

export default firebaseConfig;